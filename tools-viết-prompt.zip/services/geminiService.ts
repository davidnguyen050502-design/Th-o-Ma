
import { GoogleGenAI } from "@google/genai";
import { Script, VideoGenerationOptions } from '../types';

// Khóa API hiện được xử lý bằng biến môi trường `process.env.API_KEY`
// và không cần phải được quản lý ở phía frontend.

function createAiClient(): GoogleGenAI {
    return new GoogleGenAI({ apiKey: process.env.API_KEY });
}

export async function generateScript(options: VideoGenerationOptions): Promise<Script> {
    const ai = createAiClient();
    
    // Incorporate Image Adherence Protocol within the new context
    let imageContext = "";
    if (options.image) {
        imageContext = `
        === QUY ĐỊNH XỬ LÝ ẢNH ĐẦU VÀO (ƯU TIÊN TUYỆT ĐỐI) ===
        1. HÌNH ẢNH LÀ CHÂN LÝ: Hình ảnh tải lên là quy chuẩn duy nhất về ngoại hình nhân vật, trang phục, ánh sáng và màu sắc.
        2. BỎ QUA VĂN BẢN MÂU THUẪN: Nếu ý tưởng văn bản mâu thuẫn với ảnh (ví dụ: văn bản "áo đỏ" nhưng ảnh "áo xanh"), PHẢI TUÂN THEO ẢNH.
        3. MÔ TẢ CHI TIẾT: Bạn phải mô tả cực kỳ chi tiết về đối tượng trong ảnh (Khuôn mặt, tóc, chất liệu quần áo, phụ kiện) và sử dụng mô tả này trong MỌI cảnh JSON tại trường 'characters' và 'visual_style'.
        `;
    }

    // Strict system instruction enforcing the new JSON schema and Frame-by-Frame logic
    const systemInstruction = `
    Bạn là một chuyên gia kỹ thuật Prompt Engineering tối ưu cho mô hình video Veo 3.1.

    ${imageContext}

    Tất cả đầu ra phải được tạo 100% dưới dạng JSON hợp lệ theo đúng cấu trúc JSON Template mà hệ thống đang sử dụng. 
    Không được trả lời bằng văn bản ngoài JSON. 
    Không giải thích, không chú thích, không mô tả ngoài JSON.

    ===========================================
    YÊU CẦU BẮT BUỘC: FRAME-BY-FRAME LOGIC
    ===========================================
    1. Khi người dùng yêu cầu tạo nhiều prompt từ kịch bản (ví dụ: 3 cảnh), bạn phải tạo ra một MẢNG JSON, mỗi phần tử là một cảnh (frame sequence).
    2. Các cảnh phải được xây dựng theo TƯ DUY “Frame-by-Frame”:
       - Cảnh sau phải bắt đầu chính xác từ frame X+1 của cảnh trước.
       - Không được nhảy thời gian, không được bỏ qua hành động hoặc chuyển cảnh đột ngột.
       - time.start của cảnh n = time.end của cảnh n-1.
       - continuity_reference = tên cảnh trước đó.
    3. MỖI PROMPT MỚI BẮT BUỘC phải mở đầu bằng hành động tiếp diễn từ hành động cuối cảnh trước.
       Ví dụ:
         - Cảnh 1 kết thúc với “bước chân phải vừa chạm xuống đất”.
         - Cảnh 2 PHẢI mở đầu với “bàn chân phải tiếp tục đẩy người về phía trước…”.
    4. Camera phải duy trì sự liền mạch giữa các cảnh, tạo hiệu ứng “One Continuous Take”:
       - Giữ nguyên góc máy, tiêu cự, quỹ đạo chuyển động trừ khi có chủ đích nghệ thuật rõ ràng và mượt mà.
       - Chỉ được thay đổi mức độ nhỏ và hợp lý (ví dụ: dolly in 0.3m, pan 5 độ).
       - Tuyệt đối không được tạo cảm giác như có “cut”.

    ===========================================
    YÊU CẦU ĐỒNG NHẤT
    ===========================================
    1. Nhân vật phải đồng nhất xuyên suốt (ngoại hình, trang phục, khuôn mặt, dáng người).
    2. Bối cảnh tổng thể phải nhất quán (không được nhảy sang địa điểm khác).
    3. Âm thanh và không khí phải được mô tả nhất quán (ví dụ: tiếng gió, tiếng xe xa…).
    4. visual_style phải giữ nguyên lighting và color_palette nếu cùng một đoạn phim.

    === JSON TEMPLATE BẮT BUỘC (KHÔNG ĐƯỢC THIẾU TRƯỜNG) ===
    {
      "scene": "Tên hoặc số thứ tự cảnh",
      "time": {
        "start": 0,
        "end": 0
      },
      "continuity_reference": "Tên cảnh trước đó để tham chiếu tính liên tục",
      
      "environment": {
        "location": "Địa điểm cụ thể",
        "weather": "Thời tiết",
        "ambient_sound": ["Danh sách âm thanh nền"]
      },

      "characters": [
        {
          "name": "Tên nhân vật",
          "appearance": "Mô tả ngoại hình chi tiết",
          "outfit": "Trang phục",
          "emotion": "Cảm xúc",
          "actions": {
            "body_movement": "Chuyển động cơ thể",
            "facial_movement": "Chuyển động khuôn mặt",
            "lipsync": "Trạng thái khớp khẩu hình (nếu có thoại)"
          }
        }
      ],

      "camera": {
        "shot_type": "Loại shot (Wide, Medium, Close-up...)",
        "movement": "Chuyển động (Static, Pan, Dolly...)",
        "framing": "Bố cục",
        "focus": "Tiêu điểm",
        "lens": {
          "type": "Loại ống kính",
          "focal_length": "Tiêu cự (ví dụ: 35mm)",
          "depth_of_field": "Độ sâu trường ảnh"
        },
        "stabilization": "Độ ổn định (Handheld, Steadicam, Gimbal...)"
      },

      "visual_style": {
        "style": "Phong cách",
        "lighting": "Ánh sáng",
        "color_palette": "Bảng màu",
        "fps": 24,
        "aspect_ratio": "16:9"
      },

      "motion": {
        "subject_motion": "Mô tả chuyển động chủ thể",
        "environment_motion": "Mô tả chuyển động môi trường"
      },

      "dialogue": {
        "language": "Ngôn ngữ (hoặc 'none')",
        "line": "Lời thoại (hoặc để trống)",
        "delivery": "Cách diễn đạt"
      }
    }

    NHIỆM VỤ:
    Từ input người dùng, tự động chia thành các cảnh và trả về MẢNG JSON.
    Mỗi cảnh phải tuân thủ đúng schema trên.
    Output cuối cùng chỉ được chứa JSON hợp lệ.
    `;

    let parts: any[] = [];
    const promptText = `
    DỮ LIỆU ĐẦU VÀO TỪ GIAO DIỆN:
    - Ý tưởng Video: "${options.idea}"
    - Số lượng prompt (Số cảnh): ${options.promptCount}
    - Tỉ lệ khung hình: ${options.aspectRatio}
    - Phong cách Video: ${options.videoStyle}
    - Ngôn ngữ hội thoại: ${options.dialogueLanguage}
    
    NHIỆM VỤ:
    Tạo ra một MẢNG JSON gồm đúng ${options.promptCount} cảnh. 
    Áp dụng nghiêm ngặt tư duy Frame-by-Frame và đảm bảo tính liên tục (continuity).
    Trường "visual_style.aspect_ratio" phải là "${options.aspectRatio}".
    `;

    if (options.image && options.imageMimeType) {
        parts.push({
            inlineData: {
                mimeType: options.imageMimeType,
                data: options.image
            }
        });
        parts.push({ text: promptText + " (Sử dụng hình ảnh này làm Quy chuẩn tuyệt đối về hình ảnh nhân vật và bối cảnh)" });
    } else {
        parts.push({ text: promptText });
    }

    try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: { parts },
            config: {
                systemInstruction: systemInstruction,
                responseMimeType: 'application/json', // Force JSON output
                temperature: 0.6, 
            }
        });

        let text = response.text;
        if (!text) {
            throw new Error("AI trả về kết quả rỗng.");
        }

        // Logic xử lý chuỗi JSON thô để đảm bảo tính hợp lệ
        let jsonString = text.trim();
        
        // Loại bỏ markdown code block nếu có
        if (jsonString.startsWith('```json')) {
            jsonString = jsonString.replace(/^```json\s*/, '').replace(/\s*```$/, '');
        } else if (jsonString.startsWith('```')) {
            jsonString = jsonString.replace(/^```\s*/, '').replace(/\s*```$/, '');
        }

        // Tìm vị trí bắt đầu và kết thúc của mảng JSON
        const startIndex = jsonString.indexOf('[');
        const endIndex = jsonString.lastIndexOf(']');

        if (startIndex !== -1 && endIndex !== -1) {
            jsonString = jsonString.substring(startIndex, endIndex + 1);
        } else {
             // Nếu không tìm thấy mảng, thử tìm object đơn và bao quanh bằng mảng
            const startObj = jsonString.indexOf('{');
            const endObj = jsonString.lastIndexOf('}');
            if (startObj !== -1 && endObj !== -1) {
                 jsonString = `[${jsonString.substring(startObj, endObj + 1)}]`;
            } else {
                console.error("Raw output:", text);
                throw new Error("AI không trả về đúng định dạng JSON (Không tìm thấy mảng hoặc đối tượng hợp lệ).");
            }
        }

        let rawScenes;
        try {
            rawScenes = JSON.parse(jsonString);
        } catch (e) {
            console.error("JSON Parse Error:", e);
            console.error("Bad JSON String:", jsonString);
            throw new Error("Lỗi phân tích dữ liệu JSON từ AI. Vui lòng thử lại.");
        }

        if (!Array.isArray(rawScenes)) {
             if (typeof rawScenes === 'object' && rawScenes !== null) {
                 rawScenes = [rawScenes];
             } else {
                 throw new Error("Kết quả trả về không phải là một danh sách cảnh hợp lệ.");
             }
        }

        const mappedScenes = rawScenes.map((item: any, index: number) => ({
            scene_number: item.scene || index + 1,
            // Tạo mô tả ngắn gọn cho UI từ nội dung JSON mới
            script_description: (() => {
                // Mapping based on new schema structure
                const charAction = item.characters?.[0]?.actions?.body_movement || "";
                const subjMotion = item.motion?.subject_motion || "";
                const mainAction = charAction || subjMotion || "Diễn biến cảnh";
                const cam = item.camera?.movement ? `Cam: ${item.camera.movement}` : "";
                return `${mainAction}. ${cam}`;
            })(),
            // Veo prompt chính là toàn bộ cục JSON
            veo_prompt: JSON.stringify(item, null, 2) 
        }));

        return {
            story_summary: "Kịch bản tối ưu Frame-by-Frame cho Veo 3.1",
            scenes: mappedScenes
        };

    } catch (error: any) {
        console.error("Generative AI Error:", error);
        throw error;
    }
}

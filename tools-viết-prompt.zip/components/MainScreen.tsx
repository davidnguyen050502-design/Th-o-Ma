
import React, { useState } from 'react';
import { generateScript } from '../services/geminiService';
import { Script, Scene, VideoGenerationOptions } from '../types';
import { VIDEO_STYLES } from '../constants';
import SceneCard from './SceneCard';
import { LoadingIcon, SparklesIcon, ClipboardIcon, CheckIcon, PhotoIcon, TrashIcon } from './icons';

const MainScreen: React.FC = () => {
    const [options, setOptions] = useState<VideoGenerationOptions>({
        idea: '',
        promptCount: 3,
        videoStyle: 'Cinematic',
        aspectRatio: '16:9',
        dialogueLanguage: 'Không Có',
    });
    const [scenes, setScenes] = useState<Scene[]>([]);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [isAllCopied, setIsAllCopied] = useState(false);

    const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
        const file = event.target.files?.[0];
        if (file) {
            const reader = new FileReader();
            reader.onloadend = () => {
                const base64String = reader.result as string;
                // Remove data URL prefix to get raw base64
                const base64Data = base64String.split(',')[1];
                setOptions(prev => ({
                    ...prev,
                    image: base64Data,
                    imageMimeType: file.type
                }));
            };
            reader.readAsDataURL(file);
        }
    };

    const removeImage = () => {
        setOptions(prev => ({
            ...prev,
            image: undefined,
            imageMimeType: undefined
        }));
    };

    const handleGenerateScript = async () => {
        if (!options.idea) {
            setError('Vui lòng nhập ý tưởng video.');
            return;
        }
        setIsLoading(true);
        setError(null);
        setScenes([]);

        try {
            const script: Script = await generateScript(options);
            setScenes(script.scenes);
        } catch (err: any) {
            console.error("Error generating script:", err);
            setError('Tạo kịch bản thất bại. Vui lòng kiểm tra console để biết chi tiết và đảm bảo khóa API của bạn được cấu hình đúng.');
        } finally {
            setIsLoading(false);
        }
    };
    
    const handleCopyAllPrompts = () => {
        if (scenes.length === 0) return;
        const allPrompts = scenes.map(scene => scene.veo_prompt).join('\n\n');
        navigator.clipboard.writeText(allPrompts).then(() => {
            setIsAllCopied(true);
            setTimeout(() => setIsAllCopied(false), 2000);
        });
    };

    return (
        <main className="container mx-auto p-4 md:p-8">
            <header className="text-center mb-10">
                <h1 className="text-4xl md:text-5xl font-extrabold tracking-tight text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-indigo-600">
                    Tools By Thảo Ma
                </h1>
                <p className="mt-4 text-lg text-gray-300 max-w-2xl mx-auto">
                    Biến ý tưởng của bạn thành hiện thực điện ảnh. Mô tả tầm nhìn của bạn, tải ảnh tham khảo lên (tùy chọn) và để AI tạo ra kịch bản và prompt video hoàn hảo cho Veo 3.1.
                </p>
            </header>

            <div className="bg-gray-800 p-6 md:p-8 rounded-2xl shadow-lg border border-gray-700">
                <div className="space-y-6">
                    {/* Image Upload Section */}
                    <div>
                        <label className="block text-sm font-medium text-gray-300 mb-2">
                            Hình ảnh tham khảo (Tùy chọn)
                        </label>
                        {options.image ? (
                            <div className="relative w-full h-48 bg-gray-900 rounded-lg overflow-hidden border border-gray-600 group">
                                <img 
                                    src={`data:${options.imageMimeType};base64,${options.image}`} 
                                    alt="Reference" 
                                    className="w-full h-full object-contain"
                                />
                                <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                                    <button 
                                        onClick={removeImage}
                                        className="bg-red-600 p-2 rounded-full text-white hover:bg-red-700 transition shadow-lg"
                                        title="Xóa ảnh"
                                    >
                                        <TrashIcon className="w-6 h-6" />
                                    </button>
                                </div>
                            </div>
                        ) : (
                            <label className="flex flex-col items-center justify-center w-full h-32 border-2 border-gray-600 border-dashed rounded-lg cursor-pointer bg-gray-900/50 hover:bg-gray-700 hover:border-indigo-500 transition group">
                                <div className="flex flex-col items-center justify-center pt-5 pb-6">
                                    <PhotoIcon className="w-8 h-8 mb-3 text-gray-400 group-hover:text-indigo-400 transition" />
                                    <p className="mb-2 text-sm text-gray-400 group-hover:text-gray-200"><span className="font-semibold">Nhấn để tải ảnh lên</span> hoặc kéo thả</p>
                                    <p className="text-xs text-gray-500">PNG, JPG, WEBP (Tối đa 5MB)</p>
                                </div>
                                <input type="file" className="hidden" accept="image/*" onChange={handleImageUpload} />
                            </label>
                        )}
                    </div>

                    <div>
                        <label htmlFor="idea" className="block text-sm font-medium text-gray-300 mb-2">
                            Ý tưởng Video của bạn
                        </label>
                        <textarea
                            id="idea"
                            rows={4}
                            className="w-full bg-gray-900 border border-gray-600 rounded-lg p-3 text-white focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition"
                            placeholder="ví dụ: Một phi hành gia đơn độc phát hiện ra một tạo tác ngoài hành tinh phát sáng trên một mặt trăng hoang vắng."
                            value={options.idea}
                            onChange={(e) => setOptions({ ...options, idea: e.target.value })}
                        />
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                            <label htmlFor="promptCount" className="block text-sm font-medium text-gray-300 mb-2">Số lượng prompt</label>
                            <input
                                id="promptCount"
                                type="number"
                                className="w-full bg-gray-900 border border-gray-600 rounded-lg p-3 text-white focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition"
                                value={options.promptCount}
                                onChange={(e) => {
                                    const count = parseInt(e.target.value, 10);
                                    setOptions({ ...options, promptCount: isNaN(count) || count < 1 ? 1 : count });
                                }}
                                min="1"
                            />
                        </div>
                        <div>
                            <label htmlFor="aspectRatio" className="block text-sm font-medium text-gray-300 mb-2">Tỉ lệ khung hình</label>
                            <select
                                id="aspectRatio"
                                className="w-full bg-gray-900 border border-gray-600 rounded-lg p-3 text-white focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition"
                                value={options.aspectRatio}
                                onChange={(e) => setOptions({ ...options, aspectRatio: e.target.value })}
                            >
                                <option value="16:9">16:9 (Ngang - Youtube/Web)</option>
                                <option value="9:16">9:16 (Dọc - TikTok/Reels)</option>
                            </select>
                        </div>
                        <div>
                            <label htmlFor="videoStyle" className="block text-sm font-medium text-gray-300 mb-2">Phong cách Video</label>
                            <select
                                id="videoStyle"
                                className="w-full bg-gray-900 border border-gray-600 rounded-lg p-3 text-white focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition"
                                value={options.videoStyle}
                                onChange={(e) => setOptions({ ...options, videoStyle: e.target.value })}
                            >
                                {VIDEO_STYLES.map(style => <option key={style} value={style}>{style}</option>)}
                            </select>
                        </div>
                        <div>
                            <label htmlFor="dialogueLanguage" className="block text-sm font-medium text-gray-300 mb-2">Ngôn ngữ hội thoại</label>
                            <select
                                id="dialogueLanguage"
                                className="w-full bg-gray-900 border border-gray-600 rounded-lg p-3 text-white focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition"
                                value={options.dialogueLanguage}
                                onChange={(e) => setOptions({ ...options, dialogueLanguage: e.target.value })}
                            >
                                <option value="Không Có">Không Có</option>
                                <option value="Tiếng Việt">Tiếng Việt</option>
                                <option value="Tiếng Anh">Tiếng Anh</option>
                            </select>
                        </div>
                    </div>

                    <div className="pt-2">
                        <button
                            onClick={handleGenerateScript}
                            disabled={isLoading}
                            className="w-full flex items-center justify-center px-6 py-3.5 text-base font-medium text-white bg-indigo-600 rounded-lg hover:bg-indigo-700 focus:ring-4 focus:ring-indigo-500 focus:ring-opacity-50 transition-transform transform hover:scale-105 disabled:bg-indigo-800 disabled:cursor-not-allowed"
                        >
                            {isLoading ? (
                                <>
                                    <LoadingIcon className="w-5 h-5 mr-3 animate-spin" />
                                    Đang tạo kịch bản...
                                </>
                            ) : (
                                <>
                                    <SparklesIcon className="w-5 h-5 mr-3" />
                                    Tạo Kịch bản & Prompts
                                </>
                            )}
                        </button>
                    </div>
                </div>

                {error && <p className="mt-4 text-center text-red-400">{error}</p>}
            </div>

             {scenes.length > 0 && (
                <div className="mt-12">
                    <div className="text-center mb-8">
                        <button
                            onClick={handleCopyAllPrompts}
                            className={`px-6 py-3 text-base font-bold text-white rounded-lg transition-transform transform hover:scale-105 flex items-center justify-center mx-auto focus:ring-4 focus:ring-opacity-50 ${
                                isAllCopied 
                                    ? 'bg-green-600 hover:bg-green-700 focus:ring-green-500' 
                                    : 'bg-indigo-600 hover:bg-indigo-700 focus:ring-indigo-500'
                            }`}
                        >
                            {isAllCopied ? (
                                <>
                                    <CheckIcon className="w-5 h-5 mr-3" />
                                    Đã sao chép tất cả!
                                </>
                            ) : (
                                <>
                                    <ClipboardIcon className="w-5 h-5 mr-3" />
                                    Sao chép tất cả Prompts
                                </>
                            )}
                        </button>
                    </div>
                    <div className="space-y-8">
                        {scenes.map((scene) => (
                            <SceneCard 
                                key={scene.scene_number} 
                                scene={scene} 
                            />
                        ))}
                    </div>
                </div>
            )}
        </main>
    );
};

export default MainScreen;
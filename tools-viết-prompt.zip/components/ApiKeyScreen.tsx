// FIX: This component has been updated to remove the API key input form,
// adhering to the guideline that API keys should be handled via environment variables.
import React from 'react';

/**
 * @deprecated This component is deprecated and should not be used.
 * API key management has been moved to environment variables for security.
 * The application now relies on `process.env.API_KEY`.
 */
const ApiKeyScreen: React.FC = () => {
  // This component is intentionally left blank.
  // It was previously used for API key input, which is now handled
  // via environment variables as per security guidelines.
  return null;
};

export default ApiKeyScreen;

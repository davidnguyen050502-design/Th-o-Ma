import React, { useState } from 'react';
import { Scene } from '../types';
import { ClipboardIcon, CheckIcon } from './icons';

interface SceneCardProps {
    scene: Scene;
}

const SceneCard: React.FC<SceneCardProps> = ({ scene }) => {
    const [isPromptCopied, setIsPromptCopied] = useState(false);
    const [isDescCopied, setIsDescCopied] = useState(false);

    const handleCopyPrompt = () => {
        navigator.clipboard.writeText(scene.veo_prompt).then(() => {
            setIsPromptCopied(true);
            setTimeout(() => setIsPromptCopied(false), 2000); // Reset after 2 seconds
        });
    };

    const handleCopyDesc = () => {
        navigator.clipboard.writeText(scene.script_description).then(() => {
            setIsDescCopied(true);
            setTimeout(() => setIsDescCopied(false), 2000); // Reset after 2 seconds
        });
    };

    return (
        <div className="bg-gray-800 rounded-2xl shadow-lg border border-gray-700 overflow-hidden transition-all duration-300 hover:border-indigo-500/50 hover:shadow-indigo-500/10">
            <div className="p-6">
                <h3 className="text-xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-300 to-indigo-400">
                    Cảnh {scene.scene_number}
                </h3>
            </div>
            <div className="p-6 pt-0">
                <div className="space-y-4">
                    <div>
                        <div className="flex justify-between items-center mb-2">
                            <h4 className="font-semibold text-gray-300">Mô tả Kịch bản</h4>
                            <button
                                onClick={handleCopyDesc}
                                className={`flex items-center space-x-2 px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
                                    isDescCopied
                                        ? 'bg-green-600 text-white'
                                        : 'bg-gray-700 hover:bg-gray-600 text-gray-200'
                                }`}
                                title="Sao chép mô tả"
                            >
                                {isDescCopied ? (
                                    <>
                                        <CheckIcon className="w-4 h-4" />
                                        <span>Đã sao chép</span>
                                    </>
                                ) : (
                                    <>
                                        <ClipboardIcon className="w-4 h-4" />
                                        <span>Sao chép</span>
                                    </>
                                )}
                            </button>
                        </div>
                        <p className="text-gray-400 text-sm bg-gray-900/50 p-3 rounded-md border border-gray-700">
                            {scene.script_description}
                        </p>
                    </div>
                    <div>
                        <div className="flex justify-between items-center mb-2">
                            <h4 className="font-semibold text-gray-300">Veo Prompt (Tiếng Anh)</h4>
                            <button
                                onClick={handleCopyPrompt}
                                className={`flex items-center space-x-2 px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
                                    isPromptCopied
                                        ? 'bg-green-600 text-white'
                                        : 'bg-gray-700 hover:bg-gray-600 text-gray-200'
                                }`}
                            >
                                {isPromptCopied ? (
                                    <>
                                        <CheckIcon className="w-4 h-4" />
                                        <span>Đã sao chép!</span>
                                    </>
                                ) : (
                                    <>
                                        <ClipboardIcon className="w-4 h-4" />
                                        <span>Sao chép Prompt</span>
                                    </>
                                )}
                            </button>
                        </div>
                        <pre className="text-sm text-indigo-200 bg-gray-900/50 p-3 rounded-md border border-gray-700 whitespace-pre-wrap font-mono text-xs">
                           <code>{scene.veo_prompt}</code>
                        </pre>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default SceneCard;